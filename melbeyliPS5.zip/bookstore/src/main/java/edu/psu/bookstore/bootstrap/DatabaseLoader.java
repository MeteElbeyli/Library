package edu.psu.bookstore.bootstrap;

import edu.psu.bookstore.repository.BookRepository;
import edu.psu.bookstore.Genre;
import edu.psu.bookstore.model.Book;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class DatabaseLoader implements ApplicationListener<ContextRefreshedEvent> {

    private final BookRepository bookRepository;

    public DatabaseLoader(BookRepository bookRepository) {

        this.bookRepository = bookRepository;

    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        System.out.println("!!! *** THE SPRING APPLICATION IS NOW STARTING please wait *** !!!");
        /*
        How to add a book ->  bookRepository.addBook(new);
                Basically -> bookRepository.addBook((new Book(3123,"BOOK", 13828K28123,"Mete","03/12/2003",Genre.ROMANCE,.1)));

         */


    }
}
