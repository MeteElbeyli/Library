package edu.psu.bookstore;
// basically where the genre types are stored easier than I thought

public enum Genre {
    HORROR,NONFICTION,ROMANCE,CLASSICS;
    }
